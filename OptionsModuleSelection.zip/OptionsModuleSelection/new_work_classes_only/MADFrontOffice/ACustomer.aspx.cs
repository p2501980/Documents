﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MADClasses;

public partial class ACustomer : System.Web.UI.Page
{

    //1
    int CustomerId;

    protected void Page_Load(object sender, EventArgs e)
    {
        {
            nCustomerId = Convert.ToInt32(Session["CustomerId"]);
            if (IsPostBack == false)
            {
                if (CustomerId != -1)
                {
                    DisplayCustomer();
                }
            }
        }
    }


    //2
    protected void BtnOk_click(object sender, EventArgs e)
    {
        

        //create a new instance of the Customer Class
        ClsCustomer ACustomer = new ClsCustomer();
        
        //Capture the properties

        string Check = txtCheck.Text;
        string CustomerId = txt.CustomerIdText;
        string Username = txtUsername.Text;
        string Password = txtPassword.Text;
    
        Error = ABook.Valid(Check, CustomerId, Username, Password, JoinDate, Adress, Active);

        if (Error == "")
        {
            ACustomer.Check = Check;
            ACustomer.CustomerId = Convert.ToInt32(CustomerId);
            ACustomer.Username = Convert.ToInt32(Username);
            ACustomer.Password = Convert.ToInt32(Password);
          
          

            ClsCustomerCollection CustomerList = new clsCustomerCollection();

            if (Convert.ToInt32(nCustomerId) == -1)
            {
                CustomerList.ThisCustomer = ACustomer;
                CustomerList.Add();
               
            }
            else
            {
                CustomerList.ThisCustomer.Find(Convert.ToInt32(CustomerId));
                CustomerList.ThisStock = ACustomer;
                CustomerList.Update();
              
            }
  Response.Redirect("DefaultCustomer.aspx");

        }
        else
        {
            LabelError.Text = Error;
        }

    }


       //3
        void DisplayCustomer()
        {

        clsCustomerCollection ACustomerList = new clsCustomerCollection();

  CustomerList.ThisCustomer.Find(CustomerId);
        
//display the data

        txtCheck.Text = AllOfCustomers.ThisCustomer.Check;
        txtCustomerId.Text = AllOfCustomers.ThisCustomer.CustomerId;
        txtUsername.Text = AllOfCustomers.ThisCustomer.Username();
        txtPassword.Text = AllOfCustomers.ThisCustomer.Password.ToString(); 
       
        }
        

        //4
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            //redirect to the Viewer Page
            Response.Redirect("DefaultCustomer.aspx");
        }

  //5
  protected void btnFind_Click(object sender, EventArgs e)
    {
        clsCustomer ACustomer = new clsCutsomer();
        Int32 CustomerId;
        Boolean Found = false;
        CustomerId = Convert.ToInt32(txtCustomerId.Text);
        Found = ADepartment.Find(CustomerId);

        if(Found == true)
        {
            txtdep_Location.Text = ACustomer.Dep_Location;
            txtdep_Name.Text = ACustomer.Dep_Name;
            txtno_Employee.Text = ACustomer.No_Employees.ToString();
        }
    }

}
