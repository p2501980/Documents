﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MADClasses;

public partial class ACustomerList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack == false)
        {
            DisplayCustomer();
        }
    }
    
    //CHECK

    private void DisplayCustomer()
    {
        MADClasses.clsCustomerCollection AListOfCustomers = new MADClasses.clsCustomerCollection();
        lstCustomerList.DataSource = Stock.StockList;
        lstCustomerList.DataValueField = "CustomerId";
        lstCustomerList.DataTextField = "CustomerInitials";
        lstCustomerList.DataBind();
    }

    //CHANGE
    //event handler for add button
    protected void btnAdd_Click(object sender, EventArgs e)
    {
       
        //store -1 into the session object to indicate this is a new record
        Session["CustomerId"] = -1;
        //redirect to data entry page
        Response.Redirect("ABook.aspx");
    }





    protected void btnDelete_Click(object sender, EventArgs e)
    {
        int CustomerId;

        if (lstACustomerList.SelectedIndex != -1)
        {
            CustomerId = Convert.ToInt32(lstStockList.SelectedValue);
            Session["StockID"] = CustomerId;
            Response.Redirect("DeleteCustomer.aspx");
        }

        else
        {
            labelError.Text = "Select a customer from Customer list, and de3lete f you think it's right";

            
        }
    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {
        int CustomerId;
        if (lstACustomerList.SelectedIndex != -1)
        {
            CustomerId = Convert.ToInt32(lstACustomerList.SelectedValue);
            Session["CustomerId"] = CustomerId;

            //CHECK
            Response.Redirect("ACustomer.aspx");
        }

        else
        {   //CHECK
            labelError.Text = "Please select a record from the list to edit";

            
        }
    }

    protected void btnApply_Click(object sender, EventArgs e)
    {
        clsCustomerCollection Books = new clsCustomerCollection();


        //add customer class instaed of books  ---> maybe
        //CHANGE
        Books.ReportByBookName(txtBookName.Text);
        lstACustomerList.DataSource = Books.ACustomerList;
        lstACustomerList.DataValueField = "StockID";
        lstACustomerList.DataTextField = "BookName";
        lstACustomerList.DataBind();

    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        clsCustomerCollection AllCustomers = new clsCustomerCollection();
        
 //add customer class instaed of books  ---> maybe
        Books.ReportByBookName("");
        txtBookName.Text = "";
        lstACustomerList.DataSource = Books.CustomerList;
        lstACustomerList.DataValueField = "StockID";
        lstACustomerList.DataTextField = "BookName";
        lstACustomerList.DataBind();

    }
}
