﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MADClasses;

public partial class SupplierViewer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ClsCustomer ACustomer = new ClsCustomer();
        ACustomer = (clsSuppliers)Session["ASupplier"];
        Response.Write(ACustomer.Check)
        Response.Write(ACustomer.CustomerId);
        Response.Write(ACustomer.Username);
        Response.Write(ACustomer.Password);
        Response.Write(ACustomer.Adress);
        Response.Write(ACustomer.JoinDate);
        Response.Write(ACustomer.Active);
    }
}