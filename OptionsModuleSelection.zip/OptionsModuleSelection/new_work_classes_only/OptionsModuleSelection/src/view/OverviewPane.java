package view;
import java.time.LocalDate;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import model.Course;
import model.Name;
import model.Module;

public class OverviewPane extends GridPane {
	
   private HBox Pane3;

	public OverviewPane() 
	{
	
Pane3 = new HBox();

Pane3.setScaleX(1000);

Pane3.setScaleX(500);


//1
ListView<Module> Title1 = new ListView<Module>();

//2
ListView<Module> Title2 = new ListView<Module>();

//3
ListView<Module> Title3 = new ListView<Module>();

//4
Button Title4 = new Button("SaveOverview");

//ADDINNG STUFF

//1
this.add(Title1, 0, 0);

//2
this.add(Title2, 0, 5);

//3
this.add(Title3, 5, 5);

//4
this.add(Title4, 5, 2);

		
		
	}

}
