package view;

import java.time.LocalDate;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import model.Course;
import model.Name;
import model.Module;
import view.ModuleSelectionRootPane;
import model.StudentProfile;


public class SelectModulesPane extends GridPane {

	private HBox chuj;
	
	public SelectModulesPane() {
	
	//1	
	chuj = new HBox();
	
	chuj.setScaleX(1000);
	
	chuj.setScaleX(500);
	
	
	//1
	Label Title = new Label("Select course: ");
	
	
	//2
	ListView<Module> Title2 = new ListView<Module>();
	
	
	Title2.setPrefWidth(200.0);
	Title2.setPrefHeight(150.0);
	
	//3
	Label Title3 = new Label("Term1");
	
	//4
	Button Title4 = new Button("Add");
	
	//5
	Button Title5 = new Button("Remove");
	
    //6	
	Label Title6 = new Label("Unselected Term 2 Modules");

	//7
	ListView<Module> Title7 = new ListView<Module>();
	Title7.setPrefWidth(200.0);
	Title7.setPrefHeight(150.0);
	
	//8
	Label Title8 = new Label("Unselected Term 2 Modules");

	
	//9
	ListView<Module> n9 = new ListView<Module>();
	n9.setPrefWidth(200.0);
	n9.setPrefHeight(150.0);
	
	//10
	Label n10 = new Label("Unselected Term 2 Modules");
	
	
	//11
	ListView<Module> n11 = new ListView<Module>();
	n9.setPrefWidth(200.0);
	n9.setPrefHeight(150.0);
	
	//12
	Label n12 = new Label("Term2");
	
	//11
	Button n13 = new Button("Add");
	
	//12
	Button n14 = new Button("Remove");
	

	//13
    Label n15 = new Label("Current Term 1 Credits");
	
	
    //14
    TextField n16 = new TextField();
    
    //15
    Button n17 = new Button("Reset");
    
    //16
    Button n18 = new Button("Submit");
    
    
     //10
  	Label n19 = new Label("Selected Year Long Modules");
  	
  	
  	//11
  	ListView<Module> n20 = new ListView<Module>();
  	n20.setPrefWidth(200.0);
  	n20.setPrefHeight(150.0);
  	
  	
  //12
  	Label n21 = new Label("Selected Term1 Modules");
  	
  	
  	//13
  	ListView<Module> n22 = new ListView<Module>();
  	n22.setPrefWidth(200.0);
  	n22.setPrefHeight(150.0);
  	
  	
  //14
  	Label n23 = new Label("Selected Term 2 Modules");
  	
  	
  	//15
  	//PROBABLY THE ARRAY LIST FROM STUDENTPROFILE
  	ListView<StudentProfile> n24 = new ListView<StudentProfile>();
  	n24.setPrefWidth(200.0);
  	n24.setPrefHeight(150.0);
  	
  	//16
  	Label n25 = new Label("Current term 2 credits");
  	
  	//17
	ListView<Module> n26 = new ListView<Module>();
	n26.setPrefWidth(50.0);
  	n26.setPrefHeight(50.0);
  
    
    
    //1
	this.add(chuj, 1, 0);
	
	//2
	this.add(Title, 2, 0);
	
	Title2.setPrefWidth(200.0);
	Title2.setPrefHeight(150.0);
	
	//3
	this.add(Title2, 2, 1);
	
	//4
	this.add(Title3, 2 , 3);
	
	//5
	this.add(Title4, 2, 4);
	
	//6
	this.add(Title5, 2, 5);
	
	//7
	this.add(Title6, 2, 6);
	
	//8
	this.add(Title7, 2, 7);
	
	/*
	//9
	this.add(n10, 2, 8);
	
	//10
	this.add(n11, 2,9);
	n11.setPrefWidth(200.0);
	n11.setPrefHeight(150.0);
	*/
	
	//11
	this.add(n12, 2, 10);
	
	//11
	this.add(n13, 3, 10);
	
	//12
	this.add(n14, 4, 10);
	
	//13
	this.add(n15, 2, 13);
	
	//14
	this.add(n16, 3, 13);
	
	//15
	this.add(n17, 3, 16);
	
	//16
	this.add(n18, 5, 16);
	
	//17
	this.add(n19, 4, 0);
	
	//18
	this.add(n20, 4, 1);
	
	//19
	this.add(n21, 4, 3);
	
	//20
	this.add(n22, 4, 4);
	
	//21
	this.add(n23, 4, 5);
	
	//22
	this.add(n24, 4, 6);
	
	//23
	this.add(n25, 5, 7);
	
	//24 
	this.add(n26, 6, 7);
	
		
	}


}