package view;
import java.time.LocalDate;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import model.Course;
import model.Name;
import model.Module;

public class ReserveModulesPane extends GridPane {
	
	private ComboBox<Course> cboCreateProfilePaneCourse;
	
	private ComboBox<Module> cboOverviewSelectionPaneCourse;
	
	private ComboBox<Course> cboReservePaneCourse;
	
	private ComboBox<Course> cboSelectPaneCourse;
	
	private TextField txtSurname, txtFirstName, txtPnumber, txtEmail;
	
	private DatePicker inputDate;
	
	private Button btnCreate;

	private HBox Pane2;
	
	public ReserveModulesPane()
	{
		
		//1	
		Pane2 = new HBox();
		
		Pane2.setScaleX(1000);
		
		Pane2.setScaleX(500);
		
		
		//1
		Label Title1 = new Label("Unselected Term1 Modules");
		
		//2
		ListView<Module> Title2 = new ListView<Module>();
		Title2.setPrefWidth(200.0);
		Title2.setPrefHeight(150.0);
		
		//3
		Label Title3 = new Label("Reserved Term1 Modules");
			
		//4
	     ListView<Module> Title4 = new ListView<Module>();
		Title4.setPrefWidth(200.0);
		Title4.setPrefHeight(150.0);
		Title4.addEventHandler(arg0, arg1);
	
	    //5
		Label Title5 = new Label("Reserve 30 Credits worth of 1 term 1 modules");

		//6
		Button Title6 = new Button("Add");
		
		//7
		Button Title7 = new Button("Remove");
		
		//8
		Button Title8 = new Button("Confirm");
		
		//1
		this.add(Title1, 0, 1);
		
		//2
		this.add(Title2, 0, 2);
		
		//3
		this.add(Title3, 5, 1);
		
		//4
		this.add(Title4, 5, 2);
		
		//5
		this.add(Title5, 0, 4);
		
		//6
		this.add(Title6, 1, 4);
		
		//7
		this.add(Title7, 2, 4);
		
		//8
		//this.add(Title8, 3, 4);
		
      }
	
}
