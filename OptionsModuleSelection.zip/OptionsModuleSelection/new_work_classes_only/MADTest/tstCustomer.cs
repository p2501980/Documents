using System;
using MADClasses;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MADTest
{
    [TestClass]
    public class tstCustomer
    {
        //good test data
        //create some test data to pass to the method
       
        //maybe
        string Check = "12";


    
        string CustomerId = "11";
        string Username = "Black11";
        string Password = "ManU11";
        string Adress = "LE4-1RB";
       

        [TestMethod]
        public void InstanceOk()
        {

            //create an instance ofthe class we want to create
            ClsCustomer customer = new ClsCustomer();

           //test to see that it exists
            Assert.IsNotNull(customer);
        }


        [TestMethod]
        public void CheckPropertyOk()
        {   

            //create an instance ofthe class we want to create
            ClsCustomer customer = new ClsCustomer();
            string test = "ManU1";

            //assign the data to the property
            customer.Check = test;
            
            //test to see that it exists
            Assert.AreEqual(customer.CustomerId, test);
        }

        [TestMethod]
        public void CustomerIdPropertyOk()
        {

            //create an instance ofthe class we want to create
            ClsCustomer customer = new ClsCustomer();
            int test = 1;
            

            //assign the data to the property            
            customer.CustomerId = test;
            
            //test to see that it exists
            Assert.AreEqual(customer.CustomerId, test);
        }

        [TestMethod]
        public void UsernamePropertyOk()
        {

            //create an instance ofthe class we want to create
            ClsCustomer customer = new ClsCustomer();
            string test = "Black1";
            
            //test to see that it exists
            customer.Username = test;

            Assert.AreEqual(customer.Username, test);
        }

        [TestMethod]
        public void PasswordPropertyOk()
        {   
            //create an instance ofthe class we want to create
            ClsCustomer customer = new ClsCustomer();
            string test = "ManU1";
            
            //assign the data to the property
            customer.Password = test;

            Assert.AreEqual(customer.Password, test);
        }

        [TestMethod]
        public void AddressPropertyOk()
        {   
            //create an instance ofthe class we want to create
            ClsCustomer customer = new ClsCustomer();
            string test = "LE1 2RB";
            
             //assign the data to the property
            customer.Adress = test;
            
             //test to see that it exists
            Assert.AreEqual(customer.Adress, test);
        }

        [TestMethod]
        public void DatePropertyOk()
        {   
            //create an instance ofthe class we want to create
            ClsCustomer customer = new ClsCustomer();

            DateTime test = DateTime.Now.Date;
            
             //assign the data to the property
            customer.JoinDate = test;
            
             //test to see that it exists
            Assert.AreEqual(customer.JoinDate, test);
        }

        [TestMethod]
        public void ActivePropertyOk()
        {
            //create an instance ofthe class we want to create
            ClsCustomer customer = new ClsCustomer();

            bool test = true;
            
            //assign the data to the property 
            customer.Active = test;
            
            //test to see that it exists
            Assert.AreEqual(customer.Active, test);
        }

        [TestMethod]
        public void FindMethodOK()
        {
            
            //create an instance ofthe class we want to create     
            ClsCustomer ACustomer = new ClsCustomer();

            Boolean Found = false;

            string Check = "08/12/96";

            Found = ACustomer.Find(Check);
            
             //test to see that it exists
            Assert.IsTrue(Found);
        }


     public void ValidMethodOK()
        {
           //create an instance of the class
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "";
            //invoke the method
            Error = AnDepartment.Valid(Dep_Name, Dep_Location, No_Employees);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");

        }

 
        [TestMethod]
        public void TestNew()
        {    
            ClsCustomer customer = new ClsCustomer();
            //variable to store result
            Boolean Found = false;
            //make something to look for
            string Check = "081296";
            //invoke the method
            Found = customer.Find(Check);
            //test the result
            Assert.IsTrue(Found);
        }

        [TestMethod]
        public void TestNewFound()
        {//create a class instance
            ClsCustomer ACustomer = new ClsCustomer();
            //variable to store search result
            Boolean Found = false;
            //variable to record if the data is valid
            Boolean OK = true;
            //test data to use
            string Check = "081296";
            //invoke the method
            Found = ACustomer.Find(Check);
            //check the isbn

            if (ACustomer.Check != "081296")
            {
                OK = false;
            }
            Assert.IsTrue(OK);
        }
 
        [TestMethod]
        public void TestCustomerIdFound()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //boolean variable to store the result of the search
            Boolean Found = false;
            //boolean variable to record if data is OK (assume it is)
            Boolean OK = true;
            //create some test data to use with the method
           string Check = "08/12/96";
            //invoke the method
            Found = ACustomer.Find(Check);
            //check the property
            if (ACustomer.CustomerId != 5)
            {
                OK = false;
            }
            //test to see that the result is correct
            Assert.IsTrue(OK);
        }

      

        [TestMethod]
        public void TestUsernameFound()
        {
            //create an instance of the class we want to create
            ClsCustomer Customer = new ClsCustomer();
            //boolean variable to store the result of the search
            Boolean Found = false;
            //boolean variable to record if data is OK (assume it is)
            Boolean OK = true;
            //create some test data to use with the method
            string Check = "081296";
            //invoke the method
            Found = Customer.Find(Check);
            //check the property
            if (Customer.Username != "Black2")
            {
                OK = false;
            }
            //test to see that the result is correct
            Assert.IsTrue(OK);
        }

        [TestMethod]
        public void TestPasswordFound()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //boolean variable to store the result of the search
            Boolean Found = false;
            //boolean variable to record if data is OK (assume it is)
            Boolean OK = true;
            //create some test data to use with the method
            string Check = "081296";
            //invoke the method
            Found = ACustomer.Find(Check);
            //check the property
            if (ACustomer.Password != "ManU1")
            {
                OK = false;
            }
            //test to see that the result is correct
            Assert.IsTrue(OK);
        }

        [TestMethod]
        public void TestAdressFound()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //boolean variable to store the result of the search
            Boolean Found = false;
            //boolean variable to record if data is OK (assume it is)
            Boolean OK = true;
            //create some test data to use with the method
            string Check = "081296";
            //invoke the method
            Found = ACustomer.Find(Check);
            //check the property
            if (ACustomer.Adress != "LE1-2RB")
            {
                OK = false;
            }
            //test to see that the result is correct
            Assert.IsTrue(OK);
        }


        [TestMethod]
        public void TestJoinDateFound()
        {
            //create an instance of the class we want to create
            ClsCustomer Customer = new ClsCustomer();
            //boolean variable to store the result of the search
            Boolean Found = false;
            //boolean variable to record if data is OK (assume it is)
            Boolean OK = true;
            //create some test data to use with the method
            string Check = "081296";
             //invoke the method
            Found = Customer.Find(Check);
            //check the property
            if (Customer.JoinDate != Convert.ToDateTime("02/12/1996"))
            {
                OK = false;
            }
            //test to see that the result is correct
            Assert.IsTrue(OK);
        }

        [TestMethod]
        public void TestActiveFound()
        {
            //create an instance of the class we want to create
            ClsCustomer Customer = new ClsCustomer();
            //boolean variable to store the result of the search
            Boolean Found = false;
            //boolean variable to record if data is OK (assume it is)
            Boolean OK = true;
            //create some test data to use with the method
            string Check = "081296";
            //invoke the method
            Found = Customer.Find(Check);
            //check the property
            if (Customer.Active != false)
            {
                OK = false;
            }
            //test to see that the result is correct
            Assert.IsTrue(OK);
        }

//1

//Check property


        public void CheckMinLessOne()
        {

            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();

            //string variable to store any error message
            String Error = "it seems that (CustomerId min -1) is not right";

            //create some test data to pass to the method
            string CustomerId = "";

            //invoke the method
            Error = ACustomer.Valid(Check,CustomerId, Username, Adress, Password, JoinDate, Active);

            //test to see that the result is correct
            Assert.AreNotEqual(Error, "");
        }

        public void CheckIdNoMin()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId min) is not right";
            //create some test data to pass to the method
            string CustomerId= "1"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void CheckMinPlusOne()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId --> MIN +1) is not right";
            //create some test data to pass to the method
            string CustomerId = "2"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }



        [TestMethod]
        public void CheckIdNoMid()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId MID -1) is not right";
            //create some test data to pass to the method
            string CustomerId = "6"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void CheckNoMaxLessOne()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId MAX -1) is not right";
            //create some test data to pass to the method
            string CustomerId = "11"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void CheckMax()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId MAX) is not right";
            //create some test data to pass to the method
            string CustomerId = "12"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        public void CheckMaxPlusOne() {

            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId MAX +1) is not right";
            //create some test data to pass to the method
            string CustomerId = "13"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        public void CheckExtremeMax()
        {

            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string CustomerId = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");

   
//2
//CustomerId property
 
        public void CustomerIdMinLessOne()
        {

            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();

            //string variable to store any error message
            String Error = "it seems that (CustomerId min -1) is not right";

            //create some test data to pass to the method
            string CustomerId = "";

            //invoke the method
            Error = ACustomer.Valid(Check,CustomerId, Username, Adress, Password, JoinDate, Active);

            //test to see that the result is correct
            Assert.AreNotEqual(Error, "");
        }

        public void CustomerIdNoMin()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId min) is not right";
            //create some test data to pass to the method
            string CustomerId= "1"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void CustomerIdMinPlusOne()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId --> MIN +1) is not right";
            //create some test data to pass to the method
            string CustomerId = "2"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }



        [TestMethod]
        public void CustomerIdNoMid()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId MID -1) is not right";
            //create some test data to pass to the method
            string CustomerId = "6"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void CustomerIdNoMaxLessOne()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId MAX -1) is not right";
            //create some test data to pass to the method
            string CustomerId = "11"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void CustomerIdNoMax()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId MAX) is not right";
            //create some test data to pass to the method
            string CustomerId = "12"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        public void CustomerIdMaxPlusOne() {

            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId MAX +1) is not right";
            //create some test data to pass to the method
            string CustomerId = "13"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        public void CustomerIdExtremeMax()
        {

            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string CustomerId = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

//3

//UsernameProperty

        [TestMethod]
        public void UsernameExtremeMin()
        {
           
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Username = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void UsernameMinLessOne()
        {
           
               //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Username = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void UsernameMin()
        {
           
                //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string  Username = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void UsernameMinPlusOne()
        {
           
                //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string  Username = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void UsernameMid()
        {
                //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string  Username = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }
        
        [TestMethod]
        public void UsernameMaxMinusOne()
        {
              //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string  Username = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }



        [TestMethod]
        public void UsernameMax()
        {
               //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string  Username = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }


        [TestMethod]
        public void UsernameMaxPlusOne()
        {
               //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string  Username = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void UsernameExtremeMax()
        {     

            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string  Username = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        }

//4

//Password Propety


        [TestMethod]
        public void PasswordExtremeMin()
        {
               //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string  Password = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void PasswordMinLessOne()
        {
              //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Password = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void PasswordAddedMin()
        {
              //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Password = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void PasswordMinPlusOne()
        {
               //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Password = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }


        [TestMethod]
        public void PasswordMid()
        {
               //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Password = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void PasswordMaxMinusOne()
        {
              //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Password = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void PasswordMax()
        {  
               //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Password = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }


        [TestMethod]
        public void PasswordMaxPlusOne()
        {
              //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Password = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void PasswordExtremeMax()
        {
              //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Password = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        //4
        //Adress property


        [TestMethod]
        public void AdressExtremeMin()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string  Adress = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void AdressMinLessOne()
        {
              //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Adress = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void AdressAddedMin()
        {
              //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Adress = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void AdressMinPlusOne()
        {
               //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Adress = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }


        [TestMethod]
        public void AdressMid()
        {
               //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Adress = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void AdressMaxMinusOne()
        {
              //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Adress = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void AdressMax()
        {  
               //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Adress = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }


        [TestMethod]
        public void AdressMaxPlusOne()
        {
              //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Adress = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

        [TestMethod]
        public void AdressExtremeMax()
        {
            //create an instance of the class we want to create
            ClsCustomer ACustomer = new ClsCustomer();
            //string variable to store any error message
            String Error = "it seems that (CustomerId EXTREME MAX) is not right";
            //create some test data to pass to the method
            string Adress = "100"; //this should be ok
            //invoke the method
            Error = ACustomer.Valid(Check, CustomerId, Username, Adress, Password, JoinDate, Active);
            //test to see that the result is correct
            Assert.AreEqual(Error, "");
        }

/*

        [TestMethod]
        public void NumberOfEmployeesIncorrectFormat()
        {
            //create an instance of the class we want to create
            clsDepartment AnDepartment = new clsDepartment();
            //string variable to store any error message
            String Error = "";
            //create some test data to pass to the method
            String No_Employees = "two";
            //invoke the method
            Error = AnDepartment.Valid(Dep_Name, Dep_Location,No_Employees);
            //test to see that the result is correct
            Assert.AreNotEqual(Error, "");
        }
*/        

        }
       
    }
}
