﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MADClasses;
using System.Collections.Generic;
using MADTest;

//edit the comments!!!
//fill in the data in method 3
//change the int 32 in method 3
//fill in the data in method 4

namespace Test_Framework
{
    [TestClass]
    public class tstCustomerCollection
    {

        //1
        [TestMethod]
        public void InstanceOK()
        {
           //instance of ClsCustomerCollection
            clsCustomerCollection Customers = new clsCustomerCollection();

            //see if it exists
           
            Assert.IsNotNull(Customers);
        }

        //Correct


        //2
        [TestMethod]
        public void CustomerListOk()
        {
            //1
            //instance of ClsCustomers created
            clsCustomerCollection AllCustomers = new clsCustomerCollection();

      
            //2
            //creation of test data wih objects of type customer
            List<ClsCustomer> TestList = new List<ClsCustomer>();

            //3
            //creation of the item of type the wanted data type
            ClsCustomer TestCustomer = new ClsCustomer();

            //instances of the the variable above
            TestCustomer.Check = "TO FILL IN";
            TestCustomer.CustomerId = 1;
            TestCustomer.Username = "Astrow 15";
            TestCustomer.Password = "say my name";
            TestCustomer.Adress = "nothing";
            TestCustomer.JoinDate = DateTime.Now.Date;
            TestCustomer.Active = true;


            //add the item to the data property
            TestList.Add(TestCustomer);

            //assign the above item to the property
            AllCustomers.CustomerList = TestList;

            //check if the two values match
            Assert.AreEqual(AllCustomers.CustomerList, TestList);
        }

//CORRECT

        //3
        [TestMethod]
        public void CountPopertyOK()
        {
            //1
            //creation of an instance of class ClsCustomerCollection
            clsCustomerCollection AllCustomers = new clsCustomerCollection();

            //random test data which is to be assigned to the property
            Int32 Random = 8;

            //asassignement of the the aforementioned data to the property below
            AllCustomers.Count = Random;

            //see if the two values match
            Assert.AreNotEqual(AllCustomers.Count, Random);
        }

        //4
        [TestMethod]
        public void ThisCustomerPropertyOK()
        {

            //1
            clsCustomerCollection AllCustomers = new clsCustomerCollection();

            //2
            //test data to be assigned to pthe property
            ClsCustomer TestCustomer = new ClsCustomer();

            //assign the properties to the test data object
            TestCustomer.Check = "";
            TestCustomer.CustomerId = 1;
            TestCustomer.Username = "";
            TestCustomer.Password = "sth"
            TestCustomer.Adress = "";
            TestCustomer.JoinDate = DateTime.Now.Date;
            TestCustomer.Active = true;

            //--------------------------------------

            //assign the "test data" to the property below
            AllCustomers.ThisCustomer = TestCustomer;

            //check if the values match
            Assert.AreEqual(AllCustomers.ThisCustomer, TestCustomer);

        }

//CORRECT

        //5
        public void ListandCountOK()
        {

            //1
            //creation of an instance of class ClsCustomerCollection
            clsCustomerCollection AllCustomers = new clsCustomerCollection()

            //2
            //test data to be assigned to pthe property      
            List<ClsCustomer> TestList = new List<ClsCustomer>();

            //create the wanted 
            ClsCustomer TestCustomer = new ClsCustomer();
            //set its properties
            TestCustomerId.Check = "";
            TestCustomer.CustomerId = 7;
            TestCustomer.Username = "Store";
            TestCustomer.Password = "Liverpool";
            TestCustomer.JoinDate = "";
            TestCustomer.Active = "";
          
            TestList.Add(TestCustomer);
            //assign the data to the property
            AllCustomers.CustomerList = TestList;
            //test to see that the two values are the same
            Assert.AreEqual(AllCustomers.Count, TestList.Count);


        }


        //6

        [TestMethod]
        public void AddMethodOK()
        {

            //1
            //creation of an instance of class ClsCustomerCollection
            clsCustomerCollection AllCustomers = new clsCustomerCollection();


            //2
            //test data to be assigned to pthe property
            ClsCustomer TestItem = new ClsCustomer();

            //3
            //int variable to contain the primary key
            int PrimKey = 0;

            //set the TestItemsProperties

            TestItem.Check = "TO FILL IN ,string";
            TestItem.CustomerId = 1;
            TestItem.Username = "to fill in Username, STRING";
            TestItem.Password = "to fill in, PASSWORD, STRING";
            TestItem.Adress = "to fill in, adress";
            TestItem.JoinDate = DateTime.Now.Date;
            TestItem.Active = true;

      
            AllCustomers.ThisCustomer = TestItem;

            //add the record
            AllCustomers.Add();

         

            //find the record

            AllCustomers.ThisCustomer.Find(PrimaryKey);

            //test to see that the two values are the same

            Assert.AreEqual(AllCustomers.ThisCustomer, TestItem);


        }

//CORRECT

        //7
        [TestMethod]
        public void DeleteMethodOK()
        {

            //create an instance of the class we wnat to cretae

            clsCustomerCollection AllCustomers = new clsCustomerCollection();

            //cretae the item of the test data

            ClsCustomer TestItem = new ClsCustomer();


            //var to store the primary key

            Int32 PrimK 0;

            //set it's properties

            TestItem.Check = "TO FILL IN ,string";
            TestItem.CustomerId = 1;
            TestItem.Username = "to fill in Username, STRING";
            TestItem.Password = "to fill in, PASSWORD, STRING";
            TestItem.Adress = "to fill in, adress";
            TestItem.JoinDate = DateTime.Now.Date;
            TestItem.Active = true;

            //set this adress to the test data

            AllCustomers.ThisCustomer = TestItem;

            //add the record

            PrimaryKey = AllCustomers.Add();

            //set the primary key to the test data


            TestItem.CustomerId = PrimaryKey;

            //find the record

            Boolean Found = AllCustomers.ThisCustomer.Find(PrimK);

            Assert.IsFalse(Found);
          
        }

//CORRECT


        //8
        public void UpdateMethodOK()
        {

            //create an instance of the class we wnat to cretae

            clsCustomerCollection AllCustomers = new clsCustomerCollection();

            //cretae the item of the test data

            ClsCustomer TestCatymer = new ClsCustomer();


            //var to store the primary key

            Int32 PrimK = 0;

            //set it's properties

            TestItem.Check = "TO FILL IN ,string";
            TestItem.CustomerId = 1;
            TestItem.Username = "to fill in Username, STRING";
            TestItem.Password = "to fill in, PASSWORD, STRINGTestItem.Adress";
            TestItem.Adress = "";
            TestItem.JoinDate = DateTime.Now.Date;
            TestItem.Active = true;

            //set this adress to the test data

            AllCustomers.ThisCustomer = TestItem;

            //add the record

            PrimK = AllCustomers.Add();

            //set the primary key to the test data

            TestItem.CustomerId = PrimaryKey;

            //look for the wanted the record

            AllCustomers.ThisCustomer.Find(PrimaryKey);
             
            //delte the wnated record
            AllCustomers.Delete();

            //look for the record
            Boolean Found = AllCustomers.ThisCustomer.Find(PrimaryKey);
           
            //see if the record was found or not
            Assert.IsFalse(Found);
        }



        //9
        [TestMethod]
        public void ReportByCustomerNameMethodOK()
        {
            //create an instance of the class containing unfiltered results
            clsCustomerCollection Customers = new clsCustomerCollection();

            //create an instance of the filtered data
            clsCustomerCollection FilterCustomer = new clsCustomerCollection();
            //apply a blank string (should return all records);

            FilterCustomer.ReportByCustomerName("");
            //test to see that the two values are the same

            Assert.AreEqual(FilterCustomer.Count, Customers.Count);
        }

 //10
        [TestMethod]
        public void ReportByCustomerNameNoneFound()
        {
           
  //create an instance of the filtered data
            clsCustomerCollection FilteredCustomers = new clsCustomerCollection();
            //apply a text field that doesn't exist
            string test = "qwerty";
            FilteredCustomers.ReportByCutsomerName(test);
            //test to see that there are no records
            Assert.AreEqual(0, FilteredCustomers.Count);
        }



        }
//11
        [TestMethod]
        public void ReportByCustomerNameTestDataFound()
        {
            //create an instance of the filtered data
            clsCustomerCollection FilterACustomer = new clsDepartmentCollection();

           //variable to store the result
            Boolean OK = true;

            //add a name which does not prevail in the current context
            FilterCustomer.ReportByCustomerName("Paul Dark");

            //see if the right number of recors is found
            if (FilteredCustomer.Count == 1)
            {
                //TO BE DONE
                if (FilteredCustomer.CustomerList[0].Dep_ID != 4)
                {
                    OK = false;
                }
            }
            else
            {
                OK = false;
            }

            //check if everything is ok
            Assert.IsTrue(OK);
        }







    }
}
