﻿using System;
using System.Threading.Tasks;
using System.Linq;
using System.Text;
using System.Collections.Generic;

//TO DO
/*class8
add comments to evryting
see if the parameter added is correct(in the fucntion)
*/


namespace MADClasses
{
    public class ClsCustomer
    {

//private data member for mCheck
private string mCheck;

//private data member for mCustomerId
private string mCustomerId;

//private data member for mUsername
private String mUsername;

//private data member for mPassword
private String mPassword;

//private data member for JoinDate
private String mJoinDate

//private data member for Adress
private String mAdress

//private data member for Active
private String mActive


        //1
        //property for Check
        public string Check
        {

            get
            {
                return mCheck;
            }

            set
            {

                Check = value;
            }

        }

        //2
        //property for CustomerId
        public int CustomerId
        {
            get
            {

                return mCustomerId;

            }

            set
            {
                mCustomerId = value;
            }

        }   
        
        //3
        //property for Username
        public string Username
        {
            get {

                return mUsername;
            }

            set
            {
                mUsername = value;
            }
        }


        
        //4
        //property for Password
        public string Password
        {
            get {
                return mPassword;
            }

            set
            {
                mPassword = value;
            }
        }

        
        //5
        //property for Adress
       public string Adress
        {
            get {
                return mAdress;
            }

            set
            {
                mAdress = value;
            }
        }


        
        //6
        //property for JoinDate
        public DateTime JoinDate
        {

            get
            {
                return mJoinDate;
            }

            set
            {
                mJoinDate = value;
            }

        }


        
        //7
        //property for Active
        public bool Active
        {
            get {
                return mActive;
            }

            set
            {
                mActive = value;
            }
        }


        //8       
        public bool Find(string Check)
        {


            //create an instance of the data connection
            clsDataConnection DB = new clsDataConnection();

            //check that parameter, look at 0 at the top
            DB.AddParameter("@Check", Check);


            //execute the stored procedure
            DB.Execute("sproc_tblCustomer_FilterByCheck");

            //if one record is found(thre should be either or zero!)
            if (DB.Count == 1)
            {

               //set the private data members to the test data value
                mCheck = Convert.ToInt32(DB.DataTable.Rows[0]["CustomerId"]);
                mCustomerId = Convert.ToString(DB.DataTable.Rows[0]["Adress"]);
                mUsername = Convert.ToString(DB.DataTable.Rows[0]["Username"]);
                mPassword = Convert.ToString(DB.DataTable.Rows[0]["Password"]);
                
                //return that everyting worked ok
                return true;
            }
            
            //if no record was found
            else
            {   
                //retrun false indicating a problem
                return false;
            }
        }
       
        //9
        public string Valid(string Check,string CustomerId ,string Username, string Password)
        {

            String Error = "";
            int Customers;

//1
//---------------------------------------------------------------------------------------
//VALIDATION OF "Check" PROPERTY
//---------------------------------------------------------------------------------------

            //if the Check length is 0
            if (Check.Length == 0)
            {
                //save the error to the variable
                Error = Error + "The Password property must not be equal to 0 in character lenght";
            }
            //if the Check is too long
            if (Check.Length > 60)
            {
                //save the error to the variable
                Error = Error + "The CustomerId property must be less than 60 in charcter length";
            }


                }
            }             

//2
//---------------------------------------------------------------------------------------
//VALIDATION OF "CustomerId" PROPERTY
//---------------------------------------------------------------------------------------
            
            //if the CustomerId length is 0
            if (CustomerId.Length == 0)
            {
                //save the error to the variable
                Error = Error + "The CustomerId property must not be empty";
            }
            //if the CustomerId is too long
            if (CustomerId.Length > 60)
            {
                //save the error to the variable
                Error = Error + "The CustomerId property must not exceed the lenght of 60 characters : ";
            }

//3
//---------------------------------------------------------------------------------------
//VALIDATION OF "Username" PROPERTY
//---------------------------------------------------------------------------------------

            //if the Username length is 0
            if (Username.Length == 0)
            {
                //save the error to the variable
                Error = Error + "The Usernamme property must not be equal to 0 in character lenght";
            }
            //if the Username length is more than 60 characters long
            if (Username.Length < 60)
            {
                 //save the error to the variable
                Error = Error + "The CustomerId property must be less than 60 in charcter length";
            }
            
            
//4
//---------------------------------------------------------------------------------------
//VALIDATION OF "Password" PROPERTY
//---------------------------------------------------------------------------------------

            //if the Password lenght is 0
            if (Password.Length == 0)
            {
                //save the error to the variable
                Error = Error + "The Password property must not be equal to 0 in character lenght";
            }
            if (Password.Length > 50)
            {
                //save the error to the variable
                Error = Error + "The Password property must be less than 60 in charcter length";
            }

            //return a mistake(if any)
            return Error;

        }
    }
}

