﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
1.the class is ok, check it again though just to make sure
2. download the next labs to add the right comments
*/


namespace MADClasses
{
    public class clsCustomerCollection
    {

        //1.
        //constrctor for the class
        public clsCustomerCollection()
        {
            clsDataConnection DB = new clsDataConnection();

            DB.Execute("sproc_tblCustomerIndividual_SelectAll");

            PopulateArray(DB);

        }

        //2.
        //private data member for the list
        List<ClsCustomer> mACustomerList = new List<ClsCustomer>();

        //public property for the CustomerList
        public List<ClsCustomer> CustomerList
        {
            get
            {
                //return the private data
                return mACustomerList;
            }

            set
            {

                //set the private data
                mACustomerList = value;
            }
        }



        //3.
        //public property for count
        public int Count
        {

            get
            {
                //return the count of the list
                return mACustomerList.Count;
            }

            set
            {

                //we shall worry about this later

            }
        }
     
        // 4.
        //private data member for ThisCustomer
        ClsCustomer mACustomer = new ClsCustomer();

        //public property for "ThisCustomer"
        public ClsCustomer ThisCustomer
        {

            get
            {
                return mACustomer;
            }

            set
            {
                mACustomer = value;
            }


        }

    //5.
    void PopulateArray(clsDataConnection DB)
    {
        //populate the array list based on the data table in the parameter DB
        //var for the index
        Int32 index = 0;

        //var to store the record count
        Int32 RecordCount;

        //get the count of records
        RecordCount = DB.Count;

        //clear the private array list
        mACustomerList = new List<ClsCustomer>();

        //while there are records to process

        while (index < RecordCount)
        {


            //CHECK IF YOU NEED TO DELETE SOME OF GTHE RECORDS BELOW
            //create a blank employee
            ClsCustomer ACustomer= new ClsCustomer();

                //read in the fields from the current record
                ACustomer.Check = Convert.ToString(DB.DataTable.Rows[index]["Check"]);
                ACustomer.CustomerId = Convert.ToInt32(DB.DataTable.Rows[index]["CustomerId"]);
                ACustomer.Username = Convert.ToString(DB.DataTable.Rows[index]["Username"]);
                ACustomer.Password = Convert.ToString(DB.DataTable.Rows[index]["Password"]);
               
                //add the record to the private data member
                mCustomerList.Add(ACustomer);
                //point at the next record
                index++;

        }
    }

//6.

    public int Add()
    {
        //adds a new record to the database based on the values of thisEmployee
        //connect to the database
        clsDataConnection DB = new clsDataConnection();

        //set the parameters for the stored procedure
        DB.AddParameter("@Check", mACustomer.Check);
        DB.AddParameter("@CustomerId", mACustomer.CustomerId);
        DB.AddParameter("@Username", mACustomer.Username);
        DB.AddParameter("@Password", mACustomer.Password);
       
        //execute the query returning the primary key value
        return DB.Execute("sproc_tblCustomerIndividual_Insert");
    }

//7.

    public void Delete()
    {
        //delete the record pointed to by ACustomer
        //connect to the database
        clsDataConnection DB = new clsDataConnection();
        //set the parameters for the stored procedure
        DB.AddParameter("@Check", mACustomer.Check);
        DB.AddParameter("@CustomerId", mACustomer.CustomerId);
        DB.AddParameter("@Username", mACustomer.Username);
        DB.AddParameter("@Password", mACustomer.Password);
        
        //execute the stored procedure
        DB.Execute("sproc_tblCustomerIndividual_Delete");
    }


   //8.
    public void Update()
    {
        //update an existing record based on the values of AnEmployee
        //connect to the database
        clsDataConnection DB = new clsDataConnection();

        //set the parameters for the stored procedure
        DB.AddParameter("@CustomerId", mACustomer.CustomerId"change");
        DB.AddParameter("@Check", mACustomer.Check);
        DB.AddParameter("@Password", mACustomer.Password);
        DB.AddParameter("@Username", mACustomer.Username);

        //execute the stored procedure
        DB.Execute("sproc_tblCustomerIndividual_Update");
    }

    //9.
    public void ReportByCustomerName(string Username)
    {


             //filters the records based on an CustomerName
            //connect to the database
            clsDataConnection DB = new clsDataConnection();

            //send the Employee Name parameter to the database
            DB.AddParameter("@Check", Check);

            //execute the stored procedure
            DB.Execute("sproc_tblCustomer_FilterBydep_Name");


            //populate the array list with the data table
            PopulateArray(DB);     

    }

}

