package model;

public enum Delivery {
	TERM_1, TERM_2, YEAR_LONG
}
